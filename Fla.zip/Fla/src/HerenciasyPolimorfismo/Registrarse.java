/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HerenciasyPolimorfismo;

/**
 *
 * @author alejo
 */
public class Registrarse {
    
    private String nombre;
    private String apellido;
    private String usuario;
    private String contraseña;
    private int cod_registrarse;

    public Registrarse(String nombre, String apellido, String usuario, String contraseña, int cod_registrarse) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.cod_registrarse = cod_registrarse;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public int getCod_registrarse() {
        return cod_registrarse;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public void setCod_registrarse(int cod_registrarse) {
        this.cod_registrarse = cod_registrarse;
    }


    public String resgistrarse() {
        return "Registrarse{" + "nombre=" + nombre + ", apellido=" + apellido + ", usuario=" + usuario + ", contrase\u00f1a=" + contraseña + ", cod_registrarse=" + cod_registrarse + '}';
    }
    
    
}
