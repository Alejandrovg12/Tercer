/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class Autores {
    
    private String generodellibro;
    private String nombredellibro;
    private String nombredelautor;
    private String tipodellibro;
    private String fecha;
    private String cartelera;
    private int cod_autor;

    public Autores(String generodellibro, String nombredellibro, String nombredelautor, String tipodellibro, String fecha, String cartelera, int cod_autor) {
        this.generodellibro = generodellibro;
        this.nombredellibro = nombredellibro;
        this.nombredelautor = nombredelautor;
        this.tipodellibro = tipodellibro;
        this.fecha = fecha;
        this.cartelera = cartelera;
        this.cod_autor = cod_autor;
    }

    public String getGenerodellibro() {
        return generodellibro;
    }

    public String getNombredellibro() {
        return nombredellibro;
    }

    public String getNombredelautor() {
        return nombredelautor;
    }

    public String getTipodellibro() {
        return tipodellibro;
    }

    public String getFecha() {
        return fecha;
    }

    public String getCartelera() {
        return cartelera;
    }

    public int getCod_autor() {
        return cod_autor;
    }

    public String autores() {
        return "Autores{" + "generodellibro=" + generodellibro + ", nombredellibro=" + nombredellibro + ", nombredelautor=" + nombredelautor + ", tipodellibro=" + tipodellibro + ", fecha=" + fecha + ", cartelera=" + cartelera + ", cod_autor=" + cod_autor + '}';
    }
    
    
}
