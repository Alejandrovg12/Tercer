/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class CoIn {
    
    private String QuienesSomos;
    private String CondicionesdeUso;
    private String CondicionesdeContratacion;
    private String PoliticadePrivacidad;
    private String PoliticasdeDevolucionesyAnulaciones;
    private String PoliticadeCookies;
    private String ConfigurarCookies;
    private String ResoluciondeLitigosenLinea;
    private String OficinadeBuenasPracticas;
    private int cod_InfoLegal;
    private int cod_Conoce;
    private int cod_CoIn;

    public CoIn(String QuienesSomos, String CondicionesdeUso, String CondicionesdeContratacion, String PoliticadePrivacidad, String PoliticasdeDevolucionesyAnulaciones, String PoliticadeCookies, String ConfigurarCookies, String ResoluciondeLitigosenLinea, String OficinadeBuenasPracticas, int cod_InfoLegal, int cod_Conoce, int cod_CoIn) {
        this.QuienesSomos = QuienesSomos;
        this.CondicionesdeUso = CondicionesdeUso;
        this.CondicionesdeContratacion = CondicionesdeContratacion;
        this.PoliticadePrivacidad = PoliticadePrivacidad;
        this.PoliticasdeDevolucionesyAnulaciones = PoliticasdeDevolucionesyAnulaciones;
        this.PoliticadeCookies = PoliticadeCookies;
        this.ConfigurarCookies = ConfigurarCookies;
        this.ResoluciondeLitigosenLinea = ResoluciondeLitigosenLinea;
        this.OficinadeBuenasPracticas = OficinadeBuenasPracticas;
        this.cod_InfoLegal = cod_InfoLegal;
        this.cod_Conoce = cod_Conoce;
        this.cod_CoIn = cod_CoIn;
    }

    public String getQuienesSomos() {
        return QuienesSomos;
    }

    public String getCondicionesdeUso() {
        return CondicionesdeUso;
    }

    public String getCondicionesdeContratacion() {
        return CondicionesdeContratacion;
    }

    public String getPoliticadePrivacidad() {
        return PoliticadePrivacidad;
    }

    public String getPoliticasdeDevolucionesyAnulaciones() {
        return PoliticasdeDevolucionesyAnulaciones;
    }

    public String getPoliticadeCookies() {
        return PoliticadeCookies;
    }

    public String getConfigurarCookies() {
        return ConfigurarCookies;
    }

    public String getResoluciondeLitigosenLinea() {
        return ResoluciondeLitigosenLinea;
    }

    public String getOficinadeBuenasPracticas() {
        return OficinadeBuenasPracticas;
    }

    public int getCod_InfoLegal() {
        return cod_InfoLegal;
    }

    public int getCod_Conoce() {
        return cod_Conoce;
    }

    public int getCod_CoIn() {
        return cod_CoIn;
    }

    public void setQuienesSomos(String QuienesSomos) {
        this.QuienesSomos = QuienesSomos;
    }

    public void setCondicionesdeUso(String CondicionesdeUso) {
        this.CondicionesdeUso = CondicionesdeUso;
    }

    public void setCondicionesdeContratacion(String CondicionesdeContratacion) {
        this.CondicionesdeContratacion = CondicionesdeContratacion;
    }

    public void setPoliticadePrivacidad(String PoliticadePrivacidad) {
        this.PoliticadePrivacidad = PoliticadePrivacidad;
    }

    public void setPoliticasdeDevolucionesyAnulaciones(String PoliticasdeDevolucionesyAnulaciones) {
        this.PoliticasdeDevolucionesyAnulaciones = PoliticasdeDevolucionesyAnulaciones;
    }

    public void setPoliticadeCookies(String PoliticadeCookies) {
        this.PoliticadeCookies = PoliticadeCookies;
    }

    public void setConfigurarCookies(String ConfigurarCookies) {
        this.ConfigurarCookies = ConfigurarCookies;
    }

    public void setResoluciondeLitigosenLinea(String ResoluciondeLitigosenLinea) {
        this.ResoluciondeLitigosenLinea = ResoluciondeLitigosenLinea;
    }

    public void setOficinadeBuenasPracticas(String OficinadeBuenasPracticas) {
        this.OficinadeBuenasPracticas = OficinadeBuenasPracticas;
    }

    public void setCod_InfoLegal(int cod_InfoLegal) {
        this.cod_InfoLegal = cod_InfoLegal;
    }

    public void setCod_Conoce(int cod_Conoce) {
        this.cod_Conoce = cod_Conoce;
    }

    public void setCod_CoIn(int cod_CoIn) {
        this.cod_CoIn = cod_CoIn;
    }

    public String CoIn() {
        return "CoIn{" + "QuienesSomos=" + QuienesSomos + ", CondicionesdeUso=" + CondicionesdeUso + ", CondicionesdeContratacion=" + CondicionesdeContratacion + ", PoliticadePrivacidad=" + PoliticadePrivacidad + ", PoliticasdeDevolucionesyAnulaciones=" + PoliticasdeDevolucionesyAnulaciones + ", PoliticadeCookies=" + PoliticadeCookies + ", ConfigurarCookies=" + ConfigurarCookies + ", ResoluciondeLitigosenLinea=" + ResoluciondeLitigosenLinea + ", OficinadeBuenasPracticas=" + OficinadeBuenasPracticas + ", cod_InfoLegal=" + cod_InfoLegal + ", cod_Conoce=" + cod_Conoce + ", cod_CoIn=" + cod_CoIn + '}';
    }
    
    
}
