/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HerenciasyPolimorfismo;

/**
 *
 * @author alejo
 */
public class RedesSociales {
    
    private String InfodeRedSocial;
    private int cod_AuSe;

    public RedesSociales(String InfodeRedSocial, int cod_AuSe) {
        this.InfodeRedSocial = InfodeRedSocial;
        this.cod_AuSe = cod_AuSe;
    }

    public String getInfodeRedSocial() {
        return InfodeRedSocial;
    }

    public int getCod_AuSe() {
        return cod_AuSe;
    }

    public void setInfodeRedSocial(String InfodeRedSocial) {
        this.InfodeRedSocial = InfodeRedSocial;
    }

    public void setCod_AuSe(int cod_AuSe) {
        this.cod_AuSe = cod_AuSe;
    }

    public String RedesSociales() {
        return "RedesSociales{" + "InfodeRedSocial=" + InfodeRedSocial + ", cod_AuSe=" + cod_AuSe + '}';
    }
    
    
}
