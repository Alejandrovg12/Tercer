/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Presentacion.flayerfinal;

/**
 *
 * @author RPR-C80A404ES
 */
public class FlayerFinal {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
