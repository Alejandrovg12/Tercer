/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class IniciarSesion {
    
    private String usuario;
    private String contraseña;
    private int cod_iniciarsesion;

    public IniciarSesion(String usuario, String contraseña, int cod_iniciarsesion) {
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.cod_iniciarsesion = cod_iniciarsesion;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public int getCod_iniciarsesion() {
        return cod_iniciarsesion;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public void setCod_iniciarsesion(int cod_iniciarsesion) {
        this.cod_iniciarsesion = cod_iniciarsesion;
    }

    public String iniciarsesion() {
        return "IniciarSesion{" + "usuario=" + usuario + ", contrase\u00f1a=" + contraseña + ", cod_iniciarsesion=" + cod_iniciarsesion + '}';
    }

    
}
