/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HerenciasyPolimorfismo;

/**
 *
 * @author alejo
 */
public class NeAy {
    
    private String QueesABooks;
    private String QueeslaWebdeABooks;
    private String ABooksCadena;
    private String Devoluciones;
    private String GastosyFormasdeEnvio;
    private int cod_NecesitasAyuda;
    private int cod_Ayuda;
    private int cod_NeAy;

    public NeAy(String QueesABooks, String QueeslaWebdeABooks, String ABooksCadena, String Devoluciones, String GastosyFormasdeEnvio, int cod_NecesitasAyuda, int cod_Ayuda, int cod_NeAy) {
        this.QueesABooks = QueesABooks;
        this.QueeslaWebdeABooks = QueeslaWebdeABooks;
        this.ABooksCadena = ABooksCadena;
        this.Devoluciones = Devoluciones;
        this.GastosyFormasdeEnvio = GastosyFormasdeEnvio;
        this.cod_NecesitasAyuda = cod_NecesitasAyuda;
        this.cod_Ayuda = cod_Ayuda;
        this.cod_NeAy = cod_NeAy;
    }

    public String getQueesABooks() {
        return QueesABooks;
    }

    public String getQueeslaWebdeABooks() {
        return QueeslaWebdeABooks;
    }

    public String getABooksCadena() {
        return ABooksCadena;
    }

    public String getDevoluciones() {
        return Devoluciones;
    }

    public String getGastosyFormasdeEnvio() {
        return GastosyFormasdeEnvio;
    }

    public int getCod_NecesitasAyuda() {
        return cod_NecesitasAyuda;
    }

    public int getCod_Ayuda() {
        return cod_Ayuda;
    }

    public int getCod_NeAy() {
        return cod_NeAy;
    }

    public void setQueesABooks(String QueesABooks) {
        this.QueesABooks = QueesABooks;
    }

    public void setQueeslaWebdeABooks(String QueeslaWebdeABooks) {
        this.QueeslaWebdeABooks = QueeslaWebdeABooks;
    }

    public void setABooksCadena(String ABooksCadena) {
        this.ABooksCadena = ABooksCadena;
    }

    public void setDevoluciones(String Devoluciones) {
        this.Devoluciones = Devoluciones;
    }

    public void setGastosyFormasdeEnvio(String GastosyFormasdeEnvio) {
        this.GastosyFormasdeEnvio = GastosyFormasdeEnvio;
    }

    public void setCod_NecesitasAyuda(int cod_NecesitasAyuda) {
        this.cod_NecesitasAyuda = cod_NecesitasAyuda;
    }

    public void setCod_Ayuda(int cod_Ayuda) {
        this.cod_Ayuda = cod_Ayuda;
    }

    public void setCod_NeAy(int cod_NeAy) {
        this.cod_NeAy = cod_NeAy;
    }

    public String NeAy() {
        return "NeAy{" + "QueesABooks=" + QueesABooks + ", QueeslaWebdeABooks=" + QueeslaWebdeABooks + ", ABooksCadena=" + ABooksCadena + ", Devoluciones=" + Devoluciones + ", GastosyFormasdeEnvio=" + GastosyFormasdeEnvio + ", cod_NecesitasAyuda=" + cod_NecesitasAyuda + ", cod_Ayuda=" + cod_Ayuda + ", cod_NeAy=" + cod_NeAy + '}';
    }
    
}
