/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class GeTi {
    
    private String generodellibro;
    private String nombredellibro;
    private String nombredelautor;
    private String tipodellibro;
    private String fecha;
    private String cartelera;
    private int cod_genero;
    private int cod_tipodellibro;
    private int cod_GeTi;

    public GeTi(String generodellibro, String nombredellibro, String nombredelautor, String tipodellibro, String fecha, String cartelera, int cod_genero, int cod_tipodellibro, int cod_GeTi) {
        this.generodellibro = generodellibro;
        this.nombredellibro = nombredellibro;
        this.nombredelautor = nombredelautor;
        this.tipodellibro = tipodellibro;
        this.fecha = fecha;
        this.cartelera = cartelera;
        this.cod_genero = cod_genero;
        this.cod_tipodellibro = cod_tipodellibro;
        this.cod_GeTi = cod_GeTi;
    }

    public String getGenerodellibro() {
        return generodellibro;
    }

    public void setGenerodellibro(String generodellibro) {
        this.generodellibro = generodellibro;
    }

    public String getNombredellibro() {
        return nombredellibro;
    }

    public void setNombredellibro(String nombredellibro) {
        this.nombredellibro = nombredellibro;
    }

    public String getNombredelautor() {
        return nombredelautor;
    }

    public void setNombredelautor(String nombredelautor) {
        this.nombredelautor = nombredelautor;
    }

    public String getTipodellibro() {
        return tipodellibro;
    }

    public void setTipodellibro(String tipodellibro) {
        this.tipodellibro = tipodellibro;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getCartelera() {
        return cartelera;
    }

    public void setCartelera(String cartelera) {
        this.cartelera = cartelera;
    }

    public int getCod_genero() {
        return cod_genero;
    }

    public void setCod_genero(int cod_genero) {
        this.cod_genero = cod_genero;
    }

    public int getCod_tipodellibro() {
        return cod_tipodellibro;
    }

    public void setCod_tipodellibro(int cod_tipodellibro) {
        this.cod_tipodellibro = cod_tipodellibro;
    }

    public int getCod_GeTi() {
        return cod_GeTi;
    }

    public void setCod_GeTi(int cod_GeTi) {
        this.cod_GeTi = cod_GeTi;
    }

    @Override
    public String toString() {
        return "GeTi{" + "generodellibro=" + generodellibro + ", nombredellibro=" + nombredellibro + ", nombredelautor=" + nombredelautor + ", tipodellibro=" + tipodellibro + ", fecha=" + fecha + ", cartelera=" + cartelera + ", cod_genero=" + cod_genero + ", cod_tipodellibro=" + cod_tipodellibro + ", cod_GeTi=" + cod_GeTi + '}';
    }
    
    
}
