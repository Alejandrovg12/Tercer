 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class AuSe {
    
    private String generodellibro;
    private String nombredellibro;
    private String nombredelautor;
    private String tipodellibro;
    private String fecha;
    private String cartelera;
    private int cod_vis_libro;
    private int cod_seleccion;
    private int cod_autor;
    private int cod_AuSe;

    public AuSe(String generodellibro, String nombredellibro, String nombredelautor, String tipodellibro, String fecha, String cartelera, int cod_vis_libro, int cod_seleccion, int cod_autor, int cod_AuSe) {
        this.generodellibro = generodellibro;
        this.nombredellibro = nombredellibro;
        this.nombredelautor = nombredelautor;
        this.tipodellibro = tipodellibro;
        this.fecha = fecha;
        this.cartelera = cartelera;
        this.cod_vis_libro = cod_vis_libro;
        this.cod_seleccion = cod_seleccion;
        this.cod_autor = cod_autor;
        this.cod_AuSe = cod_AuSe;
    }

    public String getGenerodellibro() {
        return generodellibro;
    }

    public void setGenerodellibro(String generodellibro) {
        this.generodellibro = generodellibro;
    }

    public String getNombredellibro() {
        return nombredellibro;
    }

    public void setNombredellibro(String nombredellibro) {
        this.nombredellibro = nombredellibro;
    }

    public String getNombredelautor() {
        return nombredelautor;
    }

    public void setNombredelautor(String nombredelautor) {
        this.nombredelautor = nombredelautor;
    }

    public String getTipodellibro() {
        return tipodellibro;
    }

    public void setTipodellibro(String tipodellibro) {
        this.tipodellibro = tipodellibro;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getCartelera() {
        return cartelera;
    }

    public void setCartelera(String cartelera) {
        this.cartelera = cartelera;
    }

    public int getCod_vis_libro() {
        return cod_vis_libro;
    }

    public void setCod_vis_libro(int cod_vis_libro) {
        this.cod_vis_libro = cod_vis_libro;
    }

    public int getCod_seleccion() {
        return cod_seleccion;
    }

    public void setCod_seleccion(int cod_seleccion) {
        this.cod_seleccion = cod_seleccion;
    }

    public int getCod_autor() {
        return cod_autor;
    }

    public void setCod_autor(int cod_autor) {
        this.cod_autor = cod_autor;
    }

    public int getCod_AuSe() {
        return cod_AuSe;
    }

    public void setCod_AuSe(int cod_AuSe) {
        this.cod_AuSe = cod_AuSe;
    }

    @Override
    public String toString() {
        return "AuSe{" + "generodellibro=" + generodellibro + ", nombredellibro=" + nombredellibro + ", nombredelautor=" + nombredelautor + ", tipodellibro=" + tipodellibro + ", fecha=" + fecha + ", cartelera=" + cartelera + ", cod_vis_libro=" + cod_vis_libro + ", cod_seleccion=" + cod_seleccion + ", cod_autor=" + cod_autor + ", cod_AuSe=" + cod_AuSe + '}';
    }
    
}
