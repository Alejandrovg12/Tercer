/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class NecesitasAyuda {
    
    private String QueesABooks;
    private String QueeslaWebdeABooks;
    private String ABooksCadena;
    private int cod_NecesitasAyuda;

    public NecesitasAyuda(String QueesABooks, String QueeslaWebdeABooks, String ABooksCadena, int cod_NecesitasAyuda) {
        this.QueesABooks = QueesABooks;
        this.QueeslaWebdeABooks = QueeslaWebdeABooks;
        this.ABooksCadena = ABooksCadena;
        this.cod_NecesitasAyuda = cod_NecesitasAyuda;
    }

    public String getQueesABooks() {
        return QueesABooks;
    }

    public String getQueeslaWebdeABooks() {
        return QueeslaWebdeABooks;
    }

    public String getABooksCadena() {
        return ABooksCadena;
    }

    public int getCod_NecesitasAyuda() {
        return cod_NecesitasAyuda;
    }

    public void setQueesABooks(String QueesABooks) {
        this.QueesABooks = QueesABooks;
    }

    public void setQueeslaWebdeABooks(String QueeslaWebdeABooks) {
        this.QueeslaWebdeABooks = QueeslaWebdeABooks;
    }

    public void setABooksCadena(String ABooksCadena) {
        this.ABooksCadena = ABooksCadena;
    }

    public void setCod_NecesitasAyuda(int cod_NecesitasAyuda) {
        this.cod_NecesitasAyuda = cod_NecesitasAyuda;
    }

    public String NecesitasAyuda() {
        return "NecesitasAyuda{" + "QueesABooks=" + QueesABooks + ", QueeslaWebdeABooks=" + QueeslaWebdeABooks + ", ABooksCadena=" + ABooksCadena + ", cod_NecesitasAyuda=" + cod_NecesitasAyuda + '}';
    }

}
