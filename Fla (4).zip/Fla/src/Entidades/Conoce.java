/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class Conoce {
    
    private String QuienesSomos;
    private int cod_Conoce;

    public Conoce(String QuienesSomos, int cod_Conoce) {
        this.QuienesSomos = QuienesSomos;
        this.cod_Conoce = cod_Conoce;
    }

    public String getQuienesSomos() {
        return QuienesSomos;
    }

    public int getCod_Conoce() {
        return cod_Conoce;
    }

    public void setQuienesSomos(String QuienesSomos) {
        this.QuienesSomos = QuienesSomos;
    }

    public void setCod_Conoce(int cod_Conoce) {
        this.cod_Conoce = cod_Conoce;
    }

    
    public String Conoce() {
        return "Conoce{" + "QuienesSomos=" + QuienesSomos + ", cod_Conoce=" + cod_Conoce + '}';
    }
    
}
