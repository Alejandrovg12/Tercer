package HerenciasyPolimorfismo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alejo
 */
public class SeBa {
    
    private String busqueda;
    private String Resultadodebusqueda;
    private String SugerenciasSegunlaBusqueda;
    private String LibrosMasActuales;
    private String cartelera;
    private String generodellibro;
    private String nombredellibro;
    private String nombredelautor;
    private String tipodellibro;
    private int cod_vis_libro;
    private String fecha;
    private int cod_seleccion;
    private int cod_busqueda;
    private int cod_SeBa;

    public SeBa(String busqueda, String Resultadodebusqueda, String SugerenciasSegunlaBusqueda, String LibrosMasActuales, String cartelera, String generodellibro, String nombredellibro, String nombredelautor, String tipodellibro, int cod_vis_libro, String fecha, int cod_seleccion, int cod_busqueda, int cod_SeBa) {
        this.busqueda = busqueda;
        this.Resultadodebusqueda = Resultadodebusqueda;
        this.SugerenciasSegunlaBusqueda = SugerenciasSegunlaBusqueda;
        this.LibrosMasActuales = LibrosMasActuales;
        this.cartelera = cartelera;
        this.generodellibro = generodellibro;
        this.nombredellibro = nombredellibro;
        this.nombredelautor = nombredelautor;
        this.tipodellibro = tipodellibro;
        this.cod_vis_libro = cod_vis_libro;
        this.fecha = fecha;
        this.cod_seleccion = cod_seleccion;
        this.cod_busqueda = cod_busqueda;
        this.cod_SeBa = cod_SeBa;
    }

    public String getBusqueda() {
        return busqueda;
    }

    public String getResultadodebusqueda() {
        return Resultadodebusqueda;
    }

    public String getSugerenciasSegunlaBusqueda() {
        return SugerenciasSegunlaBusqueda;
    }

    public String getLibrosMasActuales() {
        return LibrosMasActuales;
    }

    public String getCartelera() {
        return cartelera;
    }

    public String getGenerodellibro() {
        return generodellibro;
    }

    public String getNombredellibro() {
        return nombredellibro;
    }

    public String getNombredelautor() {
        return nombredelautor;
    }

    public String getTipodellibro() {
        return tipodellibro;
    }

    public int getCod_vis_libro() {
        return cod_vis_libro;
    }

    public String getFecha() {
        return fecha;
    }

    public int getCod_seleccion() {
        return cod_seleccion;
    }

    public int getCod_busqueda() {
        return cod_busqueda;
    }

    public int getCod_SeBa() {
        return cod_SeBa;
    }

    public void setBusqueda(String busqueda) {
        this.busqueda = busqueda;
    }

    public void setResultadodebusqueda(String Resultadodebusqueda) {
        this.Resultadodebusqueda = Resultadodebusqueda;
    }

    public void setSugerenciasSegunlaBusqueda(String SugerenciasSegunlaBusqueda) {
        this.SugerenciasSegunlaBusqueda = SugerenciasSegunlaBusqueda;
    }

    public void setLibrosMasActuales(String LibrosMasActuales) {
        this.LibrosMasActuales = LibrosMasActuales;
    }

    public void setCartelera(String cartelera) {
        this.cartelera = cartelera;
    }

    public void setGenerodellibro(String generodellibro) {
        this.generodellibro = generodellibro;
    }

    public void setNombredellibro(String nombredellibro) {
        this.nombredellibro = nombredellibro;
    }

    public void setNombredelautor(String nombredelautor) {
        this.nombredelautor = nombredelautor;
    }

    public void setTipodellibro(String tipodellibro) {
        this.tipodellibro = tipodellibro;
    }

    public void setCod_vis_libro(int cod_vis_libro) {
        this.cod_vis_libro = cod_vis_libro;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setCod_seleccion(int cod_seleccion) {
        this.cod_seleccion = cod_seleccion;
    }

    public void setCod_busqueda(int cod_busqueda) {
        this.cod_busqueda = cod_busqueda;
    }

    public void setCod_SeBa(int cod_SeBa) {
        this.cod_SeBa = cod_SeBa;
    }

    public String SeBa() {
        return "SeBa{" + "busqueda=" + busqueda + ", Resultadodebusqueda=" + Resultadodebusqueda + ", SugerenciasSegunlaBusqueda=" + SugerenciasSegunlaBusqueda + ", LibrosMasActuales=" + LibrosMasActuales + ", cartelera=" + cartelera + ", generodellibro=" + generodellibro + ", nombredellibro=" + nombredellibro + ", nombredelautor=" + nombredelautor + ", tipodellibro=" + tipodellibro + ", cod_vis_libro=" + cod_vis_libro + ", fecha=" + fecha + ", cod_seleccion=" + cod_seleccion + ", cod_busqueda=" + cod_busqueda + ", cod_SeBa=" + cod_SeBa + '}';
    }
    
    
}
