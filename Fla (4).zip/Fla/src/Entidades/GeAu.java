/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class GeAu {
    
    private String generodellibro;
    private String nombredellibro;
    private String nombredelautor;
    private String tipodellibro;
    private String fecha;
    private String cartelera;
    private int cod_genero;
    private int cod_autor;
    private int cod_GeAu;

    public GeAu(String generodellibro, String nombredellibro, String nombredelautor, String tipodellibro, String fecha, String cartelera, int cod_genero, int cod_autor, int cod_GeAu) {
        this.generodellibro = generodellibro;
        this.nombredellibro = nombredellibro;
        this.nombredelautor = nombredelautor;
        this.tipodellibro = tipodellibro;
        this.fecha = fecha;
        this.cartelera = cartelera;
        this.cod_genero = cod_genero;
        this.cod_autor = cod_autor;
        this.cod_GeAu = cod_GeAu;
    }

    public String getGenerodellibro() {
        return generodellibro;
    }

    public String getNombredellibro() {
        return nombredellibro;
    }

    public String getNombredelautor() {
        return nombredelautor;
    }

    public String getTipodellibro() {
        return tipodellibro;
    }

    public String getFecha() {
        return fecha;
    }

    public String getCartelera() {
        return cartelera;
    }

    public int getCod_genero() {
        return cod_genero;
    }

    public int getCod_autor() {
        return cod_autor;
    }

    public int getCod_GeAu() {
        return cod_GeAu;
    }

    public void setGenerodellibro(String generodellibro) {
        this.generodellibro = generodellibro;
    }

    public void setNombredellibro(String nombredellibro) {
        this.nombredellibro = nombredellibro;
    }

    public void setNombredelautor(String nombredelautor) {
        this.nombredelautor = nombredelautor;
    }

    public void setTipodellibro(String tipodellibro) {
        this.tipodellibro = tipodellibro;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setCartelera(String cartelera) {
        this.cartelera = cartelera;
    }

    public void setCod_genero(int cod_genero) {
        this.cod_genero = cod_genero;
    }

    public void setCod_autor(int cod_autor) {
        this.cod_autor = cod_autor;
    }

    public void setCod_GeAu(int cod_GeAu) {
        this.cod_GeAu = cod_GeAu;
    }

    
    public String GeAu() {
        return "GeAu{" + "generodellibro=" + generodellibro + ", nombredellibro=" + nombredellibro + ", nombredelautor=" + nombredelautor + ", tipodellibro=" + tipodellibro + ", fecha=" + fecha + ", cartelera=" + cartelera + ", cod_genero=" + cod_genero + ", cod_autor=" + cod_autor + ", cod_GeAu=" + cod_GeAu + '}';
    }
    
    
}
