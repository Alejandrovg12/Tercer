/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HerenciasyPolimorfismo;

/**
 *
 * @author alejo
 */
public class GeSe {
    
    private String generodellibro;
    private String nombredellibro;
    private String nombredelautor;
    private String tipodellibro;
    private String fecha;
    private String cartelera;
    private int cod_genero;
    private int cod_seleccion;
    private int cod_GeSe;

    public GeSe(String generodellibro, String nombredellibro, String nombredelautor, String tipodellibro, String fecha, String cartelera, int cod_genero, int cod_seleccion, int cod_GeSe) {
        this.generodellibro = generodellibro;
        this.nombredellibro = nombredellibro;
        this.nombredelautor = nombredelautor;
        this.tipodellibro = tipodellibro;
        this.fecha = fecha;
        this.cartelera = cartelera;
        this.cod_genero = cod_genero;
        this.cod_seleccion = cod_seleccion;
        this.cod_GeSe = cod_GeSe;
    }

    public String getGenerodellibro() {
        return generodellibro;
    }

    public String getNombredellibro() {
        return nombredellibro;
    }

    public String getNombredelautor() {
        return nombredelautor;
    }

    public String getTipodellibro() {
        return tipodellibro;
    }

    public String getFecha() {
        return fecha;
    }

    public String getCartelera() {
        return cartelera;
    }

    public int getCod_genero() {
        return cod_genero;
    }

    public int getCod_seleccion() {
        return cod_seleccion;
    }

    public int getCod_GeSe() {
        return cod_GeSe;
    }

    public void setGenerodellibro(String generodellibro) {
        this.generodellibro = generodellibro;
    }

    public void setNombredellibro(String nombredellibro) {
        this.nombredellibro = nombredellibro;
    }

    public void setNombredelautor(String nombredelautor) {
        this.nombredelautor = nombredelautor;
    }

    public void setTipodellibro(String tipodellibro) {
        this.tipodellibro = tipodellibro;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setCartelera(String cartelera) {
        this.cartelera = cartelera;
    }

    public void setCod_genero(int cod_genero) {
        this.cod_genero = cod_genero;
    }

    public void setCod_seleccion(int cod_seleccion) {
        this.cod_seleccion = cod_seleccion;
    }

    public void setCod_GeSe(int cod_GeSe) {
        this.cod_GeSe = cod_GeSe;
    }

    public String GeSe() {
        return "GeSe{" + "generodellibro=" + generodellibro + ", nombredellibro=" + nombredellibro + ", nombredelautor=" + nombredelautor + ", tipodellibro=" + tipodellibro + ", fecha=" + fecha + ", cartelera=" + cartelera + ", cod_genero=" + cod_genero + ", cod_seleccion=" + cod_seleccion + ", cod_GeSe=" + cod_GeSe + '}';
    }
    
    
}
