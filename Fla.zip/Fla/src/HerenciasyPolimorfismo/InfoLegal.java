/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HerenciasyPolimorfismo;

/**
 *
 * @author alejo
 */
public class InfoLegal {
    
    private String CondicionesdeUso;
    private String CondicionesdeContratacion;
    private String PoliticadePrivacidad;
    private String PoliticasdeDevolucionesyAnulaciones;
    private String PoliticadeCookies;
    private String ConfigurarCookies;
    private String ResoluciondeLitigosenLinea;
    private String OficinadeBuenasPracticas;
    private int cod_InfoLegal;

    public InfoLegal(String CondicionesdeUso, String CondicionesdeContratacion, String PoliticadePrivacidad, String PoliticasdeDevolucionesyAnulaciones, String PoliticadeCookies, String ConfigurarCookies, String ResoluciondeLitigosenLinea, String OficinadeBuenasPracticas, int cod_InfoLegal) {
        this.CondicionesdeUso = CondicionesdeUso;
        this.CondicionesdeContratacion = CondicionesdeContratacion;
        this.PoliticadePrivacidad = PoliticadePrivacidad;
        this.PoliticasdeDevolucionesyAnulaciones = PoliticasdeDevolucionesyAnulaciones;
        this.PoliticadeCookies = PoliticadeCookies;
        this.ConfigurarCookies = ConfigurarCookies;
        this.ResoluciondeLitigosenLinea = ResoluciondeLitigosenLinea;
        this.OficinadeBuenasPracticas = OficinadeBuenasPracticas;
        this.cod_InfoLegal = cod_InfoLegal;
    }

    public String getCondicionesdeUso() {
        return CondicionesdeUso;
    }

    public String getCondicionesdeContratacion() {
        return CondicionesdeContratacion;
    }

    public String getPoliticadePrivacidad() {
        return PoliticadePrivacidad;
    }

    public String getPoliticasdeDevolucionesyAnulaciones() {
        return PoliticasdeDevolucionesyAnulaciones;
    }

    public String getPoliticadeCookies() {
        return PoliticadeCookies;
    }

    public String getConfigurarCookies() {
        return ConfigurarCookies;
    }

    public String getResoluciondeLitigosenLinea() {
        return ResoluciondeLitigosenLinea;
    }

    public String getOficinadeBuenasPracticas() {
        return OficinadeBuenasPracticas;
    }

    public int getCod_InfoLegal() {
        return cod_InfoLegal;
    }

    public void setCondicionesdeUso(String CondicionesdeUso) {
        this.CondicionesdeUso = CondicionesdeUso;
    }

    public void setCondicionesdeContratacion(String CondicionesdeContratacion) {
        this.CondicionesdeContratacion = CondicionesdeContratacion;
    }

    public void setPoliticadePrivacidad(String PoliticadePrivacidad) {
        this.PoliticadePrivacidad = PoliticadePrivacidad;
    }

    public void setPoliticasdeDevolucionesyAnulaciones(String PoliticasdeDevolucionesyAnulaciones) {
        this.PoliticasdeDevolucionesyAnulaciones = PoliticasdeDevolucionesyAnulaciones;
    }

    public void setPoliticadeCookies(String PoliticadeCookies) {
        this.PoliticadeCookies = PoliticadeCookies;
    }

    public void setConfigurarCookies(String ConfigurarCookies) {
        this.ConfigurarCookies = ConfigurarCookies;
    }

    public void setResoluciondeLitigosenLinea(String ResoluciondeLitigosenLinea) {
        this.ResoluciondeLitigosenLinea = ResoluciondeLitigosenLinea;
    }

    public void setOficinadeBuenasPracticas(String OficinadeBuenasPracticas) {
        this.OficinadeBuenasPracticas = OficinadeBuenasPracticas;
    }

    public void setCod_InfoLegal(int cod_InfoLegal) {
        this.cod_InfoLegal = cod_InfoLegal;
    }

    public String InfoLegal() {
        return "InfoLegal{" + "CondicionesdeUso=" + CondicionesdeUso + ", CondicionesdeContratacion=" + CondicionesdeContratacion + ", PoliticadePrivacidad=" + PoliticadePrivacidad + ", PoliticasdeDevolucionesyAnulaciones=" + PoliticasdeDevolucionesyAnulaciones + ", PoliticadeCookies=" + PoliticadeCookies + ", ConfigurarCookies=" + ConfigurarCookies + ", ResoluciondeLitigosenLinea=" + ResoluciondeLitigosenLinea + ", OficinadeBuenasPracticas=" + OficinadeBuenasPracticas + ", cod_InfoLegal=" + cod_InfoLegal + '}';
    }
    
    
}
